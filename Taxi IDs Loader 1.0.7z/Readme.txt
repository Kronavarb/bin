***** Taxi IDs loader by fastman92

This CLEO script allows you to change IDs of taxi vehicles used by 0602 opcode.

Compatible with GTA San Andreas v1.0 [US] HOODLUM No-CD Fixed EXE
- - - - - - -  - - - - - - - - - -

***** Installation
- Copy CLEO and data directory from an archive to your GTA San Andreas root dir.

***** Configuration of your own IDs
- Open CLEO\Taxi_IDs.dat
- Edit cheat strings only.
- Don`t modify IDs

***** License
- My plugin should not change the author
- You can share a mod anywhere

***** Thanks to: *****
Rockstar Games team who created such a good game

***** Informations:
Author: fastman92
Version: 1.0
For: GTA San Andreas
Email: fastman92@gmail.com
Visit fastman92.tk