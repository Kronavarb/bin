||||||||||||
Remember Now!
||||||||||||

--------------
Description...
--------------
Don't you hate it when you leave your vehicle to come back later and it is gone? And you have only been a few meters from it? Well this mod fixes that. The game will now remember all the vehicle, houses, peds and objects you have been around for hours and hours. Does only work the best on new and hi-res computers due to memory overload though...Enjoy... 

---------------
Installation...
---------------
1) Locate your GTA San Andreas Folder.
2) Replace your stream Configuration file in the main directory with the file included with this ReadMe.
3) Start SA and enjoy.....

----------
Contact...
----------
e-Mail = jlinw2@eq.edu.au
Website = www.jarjar.bravehost.com - New site coming soon....
MSN = jarjar_91@hotmail.com
