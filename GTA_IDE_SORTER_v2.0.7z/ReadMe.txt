IDE Sorting Script v2.0 by Inan-Ahammad . Contact: inan.ahammad17@gmail.com

Special thanks:Parik
Inspired by X-Seti`s Sorting Scripts. 

Some Q & A
-----------

Q:Is the script complete?
A:Yeah,technically!

Q:What is  this?
A:This is a c++ script which sorts IDE object ids according to your given value.

Q:What is this IDE,and why sort I dont know anything?
A:The think is,if you dont know about this.You wont necessarily need this.But you can always look up for more info
in gta wiki tough.

Q:Enter the IDE file name/location?
A:The location of your IDE file.You can just give a name of your file,if the program and file is in same folder but 
  location is also supported.

Q:Does this support multi IDE input?
A:Nope,not till now.Maybe in future. 

Q:Enter the processed file name?
A:the name of the file where your processed dta you want to be saved.you an also leave this blank and the program will
  set its name automatically using your original IDE file's name.

Q:Enter the start id no?
A:The number where your first id will start.

Verson 2.0
___________
1.Remade the full program from scratch.
2.Used higher functions.
3.The program doesnt need any line counter.
4.The program crash possibility is now far less than v1.0.
5.Now the program supports file processing from the direct file.No need to copy and paste the code in the program.
6.Overall a lot of improvements.

Verson 1.0
___________

1.The ide file will be self created.
2.Progess work prints in sorted.log file.
3.If any crash occurs,its details can be found in log.


The source code can be downloaded here https://github.com/inanahammad/GTA-IDE-ID-Sorter

Please do not upload this anywhere else without authors permisson.Thanks
