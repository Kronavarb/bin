================
 SA Map Cleaner
================
 Version 0.4b
 30.06.2005
================

Copyright � 2005 by Steve M.

Email: support@steve-m.com
Web: http://www.steve-m.com


DISCLAIMER
~~~~~~~~~~

This program is freeware and can be distributed freely, provided that the
distribution is complete in its original unmodified state, including all
documentation, copyright notice, disclaimer, and other materials provided with
the distribution.
I take no responsibility of any damage caused by the usage of this software!


What's this?
~~~~~~~~~~~~

The Map Cleaner is used to automatically remove the game objects from the GTA
San Andreas (PC) map, to make room for new maps. It will disable most map file
entries in the gta.dat and delete all unneeded model (dff) and texture (txd)
files from the game archives (img), taking care of shared objects.

For more information, help, and background info, visit this thread:
http://www.gtaforums.com/index.php?showtopic=198101


How to use it
~~~~~~~~~~~~~

Easy. Just start it, browse to the SA installation you'd like to nuke (DON'T
FORGET THE BACKUP!!!), keep the default settings in the IDE list (recommended)
or manually select the item definition files you want deleted, and press start.
The tool will take a while, since I didn't do any optimization (yet), but you
will survive it.

NOTE: The tool will NOT do any changes to any of your files until you hit the
yes button on that confirmation dialog that pops ip after it's done! So you can
safely let it run, to check if it works, and to get some test results (see
below). Also, if the tool crashes while collecting data, your SA installation
will still be ok.

Theoretically, using the default settings should work. However, for some people
(including me) the game will go into an endless loop while loading. But after I
added some custom objects (part of Myriad), it worked fine.

Included in this package is a stripped mission script (with source), that
spawns you in the middle of the map in a Hydra, and a single-line water.dat,
which gives you a complete water surface.


What it does
~~~~~~~~~~~~

First, the tool removes all IPL, IMG, SPLASH and the selected IDE entries from
your gta.dat.

Second, it will go through the IDE list and scan all UNSELECTED .ide files from
your list (including peds, vehicles and weapons) and mark the used txd, dff,
ifp and col files in the img archive as needed. It will do the same to the
radar*.txd and nodes*.dat files.

In step three, it goes through the list again, but this time scan all SELECTED
.ide files, and delete all accompanying txd, dff, ifp and col files from the
img, EXCEPT those that were marked as needed in step two. This should avoid
shared files to be deleted (like generic texture packs and such). Also, all
.ipl files are deleted from the archive.

After that, the tool will create a file named clean.log in your SA directory,
which contains a list off all remaining files in the img that were neither
deleted nor marked as needed. So theoretically these files should be unused,
but not all of them are. There are a lot of ifp files left, also all the actors
that appear during the missions (no peds though, so they could be deleted as
well), and also the special body textures for some of the cars. Based on that
list, you can try to delete files and test if it works. ;)

When it's done, it asks you if you want to apply the changes. If you choose
yes, the gta.dat will be written, the img file list updated, and the
img_int.img deleted. If you choose no, absolutely no changes will be done to
your installation, only the clean.log is created.


If there are any problems, questions, mistakes, bugs or something else simply
send an email! (support@steve-m.com)

Enjoy

Steve

Many thanks to illspirit for his help!