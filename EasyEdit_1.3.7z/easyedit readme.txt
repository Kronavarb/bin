=================
About:
=================

Name: EasyEdit
Filename: EasyEdit.dll
Version: 1.3
Author: Donny78

=================
Credits: 
=================

Google ;)

=================
Requirements:
=================

GTA San Andreas
NET framework 4.0
Visual studio (express) for development

=================
Description:
=================

This library makes it easy to hook into the San Andreas process and manipulate it's memory values using the .NET programming languages.

=================
Usage:
=================

1. Extract the contents of "EasyEdit.zip" onto your system
2. Copy the "EasyEdit.dll" and the "EasyEdit.xml" files into your projects solution folder
3. Add a reference to the EasyEdit library in your project
4. Add "using EasyEdit;" to the top of your code file along with the other "using" keywords
5. Use the functions provided by EasyEdit using the "Easy" class
6. Run your project, EasyEdit will either launch or hook San Andreas singleplayer

=================
Updates:
=================

06/12/2010 		- 	Initial release

07/12/2010		-   Added "StopSanAndreas" - Kills the San Andreas process
					Added "AreKeysPressed" - Checks if two keys are currently pressed, a wrapper around "IsKeyPressed" for ease of use
					Added "WriteScmInt, WriteScmSingle, ReadScmInt, ReadScmSingle" - read/write global variable values from/to the SCM
					Added a second constructor method which allows a path to be passed for applications outside the SA root folder
					Updated all string functions with a boolean encoding setting
					Updated the intellisense to include return types in all none void functions
					Updated the intellisense to reflect the changes in 1.1
					
08/12/2010		-	Added quite a few constants containing either a base or an offset for usefull addresses


12/12/2010		-	Removed the executable name requirement for the constructors path parameter
					Added "GetPlayerPointer" and "GetPlayerVehilePointer" functions for ease of use
					Corrected some of the constant names to reflect the value more clearly

=================
Usage Agreement:
=================    

To use this library you must agree to these terms:

1. You agree not to use this library for any type of commercial gain/use
2. You agree to credit the original author when using the library and it's functions in your code
3. You agree not to use this library to cheat/exploit or gain any type of advantage in any multiplayer environment
4. You agree to pay Donny78 ten million pounds and if not atleast think about it !

=================
Disclaimer:
=================

This library is provided 'as is', without any explicit or implied warranty. 
The author can't be held accountable for any damage that might be caused by this library or any of it's components.
The author is not accountable for any third party mods created using this library