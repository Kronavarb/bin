***** Cheat Strings loader by Fastman92

Ever wanted to modify cheat strings you enter in GTA SA? Or wanted to disable at least one cheat?
If yes, then this mod is for you.
As the name implies, a long CLEO script with function written in Assembly will load cheat strings from .dat file.
So that you can invent your own cheat strings and share the .dat file along with .cs base.

Fully compatible with GTA San Andreas v1.0 [US] HOODLUM No-CD Fixed EXE & GTA: San Andreas v1.01 [EURO] No-CD/Fixed EXE
- - - - - - -  - - - - - - - - - -

***** Installation
- Copy CLEO and data directory from an archive to your GTA San Andreas root dir.

***** Configuration of your own cheat strings
- Open data\CheatStrings.dat
- Edit cheat strings only.
- Don`t modify IDs

***** Changes:
- NULL or UNDEFINED cheat strings are reserved; They disable cheat.
- completely rewritten from zero and now ASM code is much better

***** License
- You are allowed to share your own .dat file with new cheats, but link to base of my mod (.cs loader) instead of merging it together.
- You shouldn`t share .cs file, because there might be a new version of the mod in the future.

***** Thanks to: *****
seggaeman - for attribution of original strings to cheats in cheatStrings.dat file.
Rockstar Games team who created such a good game

***** Informations:
Author: fastman92
Version: 2.0
For: GTA San Andreas
Email: fastman92@gmail.com
Visit fastman92.tk